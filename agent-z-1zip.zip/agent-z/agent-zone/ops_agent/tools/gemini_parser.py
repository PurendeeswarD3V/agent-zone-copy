"""
End-to-end utility that:

1. Converts the first two pages of a PDF to PNGs.
2. Sends each page to Gemini via Vertex AI
3. Receives the extracted entities - including
      • graph_data.graph_points   (raw x/y pairs from a plot or embedded CSV)
      • document_control.remarks  (free-text notes)
"""

import json
from pathlib import Path
import os
from pdf2image import convert_from_path
from dotenv import load_dotenv

import vertexai
from vertexai.generative_models import GenerativeModel, Part, Image
from google.oauth2 import service_account
from . import prompts
import docx
import openpyxl
import pandas as pd

# --------------------------------------------------------------------------- #
#                                 CONFIG                                      #
# --------------------------------------------------------------------------- #

poppler_path = None                          # r"C:\tools\poppler\bin"
MAX_PAGES_TO_PROCESS = 2
# --------------------------------------------------------------------------- #
#                             HELPER FUNCTIONS                                #
# --------------------------------------------------------------------------- #

def strip_fence(text: str) -> str:
    """Remove `````` fences if present."""
    text = text.strip()
    if text.startswith("```"):
        parts = text.split("```")
        if len(parts) >= 2:
            text = parts[1].lstrip("json").lstrip()
    return text

# --- Functions to read file content ---

def read_txt(file_path: str) -> str:
    """Reads content from a .txt file."""
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()

def read_docx(file_path: str) -> str:
    """Reads content from a .docx file."""
    if not docx:
        raise ImportError("The 'python-docx' library is required to read .docx files.")
    doc = docx.Document(file_path)
    return "\n".join([para.text for para in doc.paragraphs])

def read_xlsx_xls(file_path: str) -> str:
    """Reads content from an .xlsx or .xls file using pandas."""
    if not pd:
        raise ImportError("The 'pandas', 'openpyxl', and 'xlrd' libraries are required to read Excel files.")
    # Read all sheets into a dictionary of DataFrames
    xls = pd.ExcelFile(file_path)
    content = []
    for sheet_name in xls.sheet_names:
        df = pd.read_excel(xls, sheet_name=sheet_name)
        content.append(f"--- Sheet: {sheet_name} ---\n")
        content.append(df.to_string())
    return "\n".join(content)

def read_csv(file_path: str) -> str:
    """Reads content from a .csv file using pandas."""
    if not pd:
        raise ImportError("The 'pandas' library is required to read .csv files.")
    df = pd.read_csv(file_path)
    return df.to_string()


def parse_text_content(text_content: str, doc_type: str, service_account_file: str, location: str, output_folder: str, file_url: str, file_name: str) -> str:
    """
    Parses text content based on its classified type, extracts structured data using Gemini,
    and saves it as a JSONL file.

    Args:
        text_content (str): The text content of the file.
        doc_type (str): The classified type of the document (e.g., "LAB_REPORT", "ODOT_DOCUMENT").
        service_account_file (str): The path to the service account JSON file.
        location (str): The GCP location.
        output_folder (str): The folder to save the resulting JSONL file.
        file_url (str): The URL of the file.
        file_name (str): The name of the file.

    Returns:
        str: The path to the resulting JSONL file, or an empty string if parsing fails.
    """
    print(f"📄 Parsing text content from {file_name} as document type: {doc_type}")

    try:
        # Initialize Vertex AI
        vertexai.init(project=os.getenv("GOOGLE_CLOUD_PROJECT"), location=location)

        # Select model and prompts based on document type
        model = GenerativeModel("gemini-2.5-pro")

        if doc_type == "LAB_REPORT":
            prompt_text = prompts.LAB_REPORT_PROMPT
            schema_text = prompts.LAB_REPORT_SCHEMA
        elif doc_type == "ODOT_DOCUMENT":
            prompt_text = prompts.ODOT_DOCUMENT_PROMPT
            schema_text = prompts.ODOT_DOCUMENT_SCHEMA
        else:
            print(f"⚠️ No parser configuration for document type '{doc_type}'.")
            return ""

        # Construct the prompt with the text content
        prompt_parts = [prompt_text, "JSON schema:", schema_text, "File Content:", text_content]

        # Generate content
        response = model.generate_content(prompt_parts)

        # Clean and save the response
        cleaned_json = strip_fence(response.text)

        jsonl_output_path = Path(output_folder) / Path(file_name).with_suffix(".jsonl")

        with open(jsonl_output_path, "w") as f:
            try:
                data = json.loads(cleaned_json)
                if isinstance(data, list):
                    for item in data:
                        item['file_url'] = file_url
                        item['file_name'] = file_name
                        f.write(json.dumps(item) + "\n")
                else:
                    data['file_url'] = file_url
                    data['file_name'] = file_name
                    f.write(json.dumps(data) + "\n")
            except json.JSONDecodeError as err:
                print(f"❌ Error during parsing of {file_name}: {err}")
                return ""

        print(f"✅ Parsed successfully. Output: {jsonl_output_path}")
        return str(jsonl_output_path)

    except Exception as e:
        print(f"❌ Error during text content parsing: {e}")
        return ""


def parse_pdf(pdf_path: str, doc_type: str, service_account_file: str, location: str, output_image_folder: str, file_url: str, file_name: str) -> str:
    """
    Parses a PDF based on its classified type, extracts structured data using Gemini,
    and saves it as a JSONL file.

    Args:
        pdf_path (str): The path to the PDF file.
        doc_type (str): The classified type of the document (e.g., "LAB_REPORT", "ODOT_DOCUMENT").
        service_account_file (str): The path to the service account JSON file.
        location (str): The GCP location.
        output_image_folder (str): The folder to save the intermediate PNG images.
        file_url (str): The URL of the file.
        file_name (str): The name of the file.

    Returns:
        str: The path to the resulting JSONL file, or an empty string if parsing fails.
    """
    print(f"📄 Parsing {os.path.basename(pdf_path)} as document type: {doc_type}")

    try:
        # Initialize Vertex AI
        vertexai.init(project=os.getenv("GOOGLE_CLOUD_PROJECT"), location=location)

        # Convert PDF to images
        images = convert_from_path(
            pdf_path,
            last_page=MAX_PAGES_TO_PROCESS,
            output_folder=output_image_folder,
            poppler_path=poppler_path,
            fmt="png",
        )

        image_paths = [img.filename for img in images]
        image_parts = [Part.from_image(Image.load_from_file(p)) for p in image_paths]
        
        # Select model and prompts based on document type
        model = GenerativeModel("gemini-2.5-pro")
        
        if doc_type == "LAB_REPORT":
            prompt_text = prompts.LAB_REPORT_PROMPT
            schema_text = prompts.LAB_REPORT_SCHEMA
        elif doc_type == "ODOT_DOCUMENT":
            prompt_text = prompts.ODOT_DOCUMENT_PROMPT
            schema_text = prompts.ODOT_DOCUMENT_SCHEMA
        else:
            print(f"⚠️ No parser configuration for document type '{doc_type}'.")
            return ""

        # Construct the prompt
        prompt_parts = [prompt_text, "JSON schema:", schema_text, *image_parts]

        # Generate content
        response = model.generate_content(prompt_parts)
        
        # Clean and save the response
        cleaned_json = strip_fence(response.text)
        
        jsonl_output_path = Path(output_image_folder) / Path(file_name).with_suffix(".jsonl")

        with open(jsonl_output_path, "w") as f:
            # The model may return a single JSON object or a list of objects
            try:
                data = json.loads(cleaned_json)
                if isinstance(data, list):
                    for item in data:
                        item['file_url'] = file_url
                        item['file_name'] = file_name
                        f.write(json.dumps(item) + "\n")
                else:
                    data['file_url'] = file_url
                    data['file_name'] = file_name
                    f.write(json.dumps(data) + "\n")
            except json.JSONDecodeError as err:
                print(f"❌ Error during parsing of {os.path.basename(pdf_path)}: {err}")
                return ""
        
        print(f"✅ Parsed successfully. Output: {jsonl_output_path}")
        return str(jsonl_output_path)
        
    except Exception as e:
        print(f"❌ Error during parsing: {e}")
        return ""