
import os

def classify_document_by_filename(file_path: str) -> str:
    """
    Classifies a document as either a LAB_REPORT, ODOT_DOCUMENT, or UNKNOWN
    based on keywords in its filename.

    Args:
        file_path: The local path to the file.

    Returns:
        A string indicating the document type.
    """
    filename = os.path.basename(file_path).upper() # Use uppercase for case-insensitive matching

    # --- Classification Logic ---
    if "LAB" in filename:
        print(f"✅ Document '{filename}' classified as LAB_REPORT based on filename.")
        return "LAB_REPORT"
    
    if "ODOT" in filename and "LOT" in filename:
        print(f"✅ Document '{filename}' classified as ODOT_DOCUMENT based on filename.")
        return "ODOT_DOCUMENT"

    print(f"✅ Document '{filename}' classified as UNKNOWN.")
    return "UNKNOWN"


# classify_document_by_filename(r"C:\Users\Owner\Downloads\Copy of ODOT S3 70-28 Lot 6 4-23-25.pdf")
# classify_document_by_filename(r"C:\Users\Owner\Desktop\New folder (3)\adk-rag-agent-main\lab_report.pdf")