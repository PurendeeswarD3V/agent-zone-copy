import os
from google.oauth2 import service_account
from google.auth import default as default_creds

SA_KEY_PATH = os.getenv("SA_KEY_PATH")
SCOPES = [
    "https://www.googleapis.com/auth/cloud-platform",
    "https://www.googleapis.com/auth/drive.readonly",
    "https://www.googleapis.com/auth/drive"
]

def get_service_account_credentials():
    """
    Returns credentials. For local development, it uses the service account key file.
    In a deployed GCP environment, it uses Application Default Credentials.
    """
    # If SA_KEY_PATH is defined and the file exists, use it (for local dev)
    if SA_KEY_PATH and os.path.exists(SA_KEY_PATH):
        print(f"✅ Using service account key from: {SA_KEY_PATH}")
        return service_account.Credentials.from_service_account_file(
            SA_KEY_PATH, scopes=SCOPES
        )

    # Otherwise, use Application Default Credentials (for Cloud Run)
    print("✅ Using Application Default Credentials.")
    creds, _ = default_creds(scopes=SCOPES)
    return creds