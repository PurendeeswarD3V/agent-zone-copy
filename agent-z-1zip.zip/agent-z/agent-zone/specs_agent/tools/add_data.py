"""
Tool for adding new data sources to a Vertex AI RAG corpus.
"""

import re
import json
from typing import List
import os
import tempfile
import shutil
from google.adk.tools.tool_context import ToolContext
from vertexai import rag
from google.cloud import storage
from google.cloud.exceptions import NotFound

from specs_agent.config import (
    DEFAULT_CHUNK_OVERLAP,
    DEFAULT_CHUNK_SIZE,
    DEFAULT_EMBEDDING_REQUESTS_PER_MIN,
)
from .utils import get_corpus_resource_name
from .google_drive_utils import download_file_from_drive, get_files_from_folder, get_file_name_from_drive
from .gemini_parser import parse_pdf, parse_text_content, read_txt, read_docx, read_xlsx_xls, read_csv
from .document_classifier import classify_document_by_filename # Import the classifier

# --- CONFIGURATION ---
SA_KEY = os.getenv("SA_KEY_PATH")
GOOGLE_CLOUD_LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")
GCS_BUCKET_NAME = os.getenv("GCS_BUCKET_NAME")
MAPPING_FILE_NAME = "source_mapping.json"

# Define a dedicated temporary directory for this agent's files
TEMP_DIR = os.path.join(tempfile.gettempdir(), "rag_agent_temp")

def _get_gcs_blob(blob_name: str):
    """Gets a GCS blob object."""
    if not GCS_BUCKET_NAME:
        raise ValueError("GCS_BUCKET_NAME environment variable not set.")
    
    storage_client = storage.Client()
    
    # +++ START DIAGNOSTIC MODIFICATION +++
    # This will print the exact service account email being used for GCS operations.
    print("--- DIAGNOSTIC INFO ---")
    print(f"GCS Client is using credentials for service account: {storage_client.get_service_account_email()}")
    print("-----------------------")
    # +++ END DIAGNOSTIC MODIFICATION +++

    bucket = storage_client.bucket(GCS_BUCKET_NAME)
    return bucket.blob(blob_name)

def _update_source_mapping(new_mappings: dict):
    """Reads, updates, and writes the source mapping file in GCS."""
    blob = _get_gcs_blob(MAPPING_FILE_NAME)
    try:
        mapping_data = json.loads(blob.download_as_string())
    except NotFound:
        mapping_data = {}
    
    mapping_data.update(new_mappings)
    
    blob.upload_from_string(
        json.dumps(mapping_data, indent=4),
        content_type="application/json"
    )
    print(f"✅ Updated source mapping file: {MAPPING_FILE_NAME}")


def setup_temp_dir():
    """Creates or clears a dedicated temporary directory."""
    if os.path.exists(TEMP_DIR):
        shutil.rmtree(TEMP_DIR)
    os.makedirs(TEMP_DIR, exist_ok=True)
    print(f"✅ Temporary directory cleared and ready at: {TEMP_DIR}")

def upload_to_gcs(local_path: str, destination_blob_name: str) -> str:
    """Uploads a local file to the GCS bucket and returns the GCS URI."""
    blob = _get_gcs_blob(destination_blob_name)
    blob.upload_from_filename(local_path)
    
    gcs_uri = f"gs://{GCS_BUCKET_NAME}/{destination_blob_name}"
    print(f"✅ File {local_path} uploaded to {gcs_uri}")
    return gcs_uri

def process_drive_file(file_id: str, original_path: str, doc_type: str, file_name: str) -> dict:
    """Helper function to process a single Google Drive file."""
    # --- list of supported extensions ---
    supported_extensions = ('.PDF', '.DOCX', '.PPTX', '.HTML', '.MD', '.TXT', '.JSON', '.JSONL', '.XLSX', '.XLS', '.CSV')
    if not file_name.upper().endswith(supported_extensions):
         return {"status": "error", "message": f"Unsupported file type for parsing: {file_name}"}

    try:
        file_content_bytesio = download_file_from_drive(file_id)
        if file_content_bytesio:
            # Save the downloaded file to our dedicated temp directory
            temp_file_path = os.path.join(TEMP_DIR, file_name)
            with open(temp_file_path, "wb") as f:
                f.write(file_content_bytesio.getbuffer())

            json_output_path = ""
            file_ext = os.path.splitext(file_name)[1].lower()

            # --- Logic to handle different file types ---
            if file_ext == '.pdf':
                json_output_path = parse_pdf(
                    pdf_path=temp_file_path,
                    doc_type=doc_type,
                    service_account_file=SA_KEY, # SA_KEY is still needed here for Gemini
                    location=GOOGLE_CLOUD_LOCATION,
                    output_image_folder=TEMP_DIR,
                    file_url=original_path,
                    file_name=file_name
                )
            else:
                # For non-PDF files, read the content into text
                text_content = ""
                try:
                    if file_ext == '.txt':
                        text_content = read_txt(temp_file_path)
                    elif file_ext == '.docx':
                        text_content = read_docx(temp_file_path)
                    elif file_ext in ['.xlsx', '.xls']:
                        text_content = read_xlsx_xls(temp_file_path)
                    elif file_ext == '.csv':
                        text_content = read_csv(temp_file_path)

                    if text_content:
                         json_output_path = parse_text_content(
                            text_content=text_content,
                            doc_type=doc_type,
                            service_account_file=SA_KEY, # SA_KEY is still needed here for Gemini
                            location=GOOGLE_CLOUD_LOCATION,
                            output_folder=TEMP_DIR,
                            file_url=original_path,
                            file_name=file_name
                        )
                except Exception as e:
                     return {"status": "error", "message": f"Failed to read content from {file_name}: {e}"}


            if json_output_path:
                blob_name = f"parsed_pdfs/{os.path.basename(json_output_path)}"
                gcs_uri = upload_to_gcs(json_output_path, blob_name)
                # Return the mapping to be added later
                mapping = {gcs_uri: original_path}
                return {"status": "success", "path": gcs_uri, "mapping": mapping, "conversion": f"{original_path} -> (parsed) -> {gcs_uri}"}
            else:
                # This could be because parsing failed or because it's an unhandled text-based type
                return {"status": "warning", "path": original_path, "message": f"File parsing failed or is not supported for {original_path}. Adding original file link instead."}
        else:
            return {"status": "error", "message": f"Download failed for {original_path}"}
    except Exception as e:
        return {"status": "error", "message": f"Error processing {original_path}: {e}"}

def add_data(
    paths: List[str],
    tool_context: ToolContext,
) -> dict:
    """
    Add new data sources to a Vertex AI RAG corpus.
    """
    corpus_name = "specs-agent"
    setup_temp_dir()

    validated_paths = []
    invalid_paths = []
    failed_uploads = []
    skipped_preprocessing = []
    conversions = []
    new_source_mappings = {}
    
    all_paths_to_process = list(paths)

    while all_paths_to_process:
        path = all_paths_to_process.pop(0)

        if not path or not isinstance(path, str):
            invalid_paths.append(f"{path} (Not a valid string)")
            continue
            
        folder_match = re.match(r"https:\/\/drive\.google\.com\/drive\/folders\/([a-zA-Z0-9_-]+)", path)
        if folder_match:
            folder_id = folder_match.group(1)
            print(f"📂 Expanding Google Drive folder: {folder_id}")
            files_in_folder = get_files_from_folder(folder_id)
            if files_in_folder:
                all_paths_to_process.extend(files_in_folder)
                print(f"✅ Found {len(files_in_folder)} files to process in folder.")
            else:
                print(f"⚠️ No files found in folder or folder is inaccessible: {path}")
            continue

        docs_match = re.match(r"https:\/\/docs\.google\.com\/(?:document|spreadsheets|presentation)\/d\/([a-zA-Z0-9_-]+)", path)
        if docs_match:
            file_id = docs_match.group(1)
            drive_url = f"https://drive.google.com/file/d/{file_id}/view"
            all_paths_to_process.insert(0, drive_url)
            conversions.append(f"{path} → {drive_url}")
            continue

        drive_match = re.match(r"https:\/\/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)", path)
        if drive_match:
            file_id = drive_match.group(1)
            
            file_name = get_file_name_from_drive(file_id)
            if not file_name:
                invalid_paths.append(f"Could not retrieve file name for {path}")
                continue

            doc_type = classify_document_by_filename(file_name)
            
            if doc_type in ["LAB_REPORT", "ODOT_DOCUMENT"]:
                result = process_drive_file(file_id, path, doc_type, file_name)
                if result["status"] == "success":
                    validated_paths.append(result["path"])
                    conversions.append(result["conversion"])
                    new_source_mappings.update(result.get("mapping", {}))
                elif result["status"] == "warning":
                    validated_paths.append(result["path"])
                    skipped_preprocessing.append(result["path"])
                    print(f"⚠️ {result['message']}")
                else:
                    failed_uploads.append({"path": path, "reason": result["message"]})
            else:
                validated_paths.append(path)
                conversions.append(f"{path} -> (direct ingest)")
            continue

        if path.startswith("gs://"):
            validated_paths.append(path)
            continue

        invalid_paths.append(f"{path} (Invalid format)")

    if not validated_paths:
        return {
            "status": "error",
            "message": "No valid paths provided. Please provide Google Drive URLs or GCS paths.",
            "corpus_name": corpus_name,
            "invalid_paths": invalid_paths,
            "failed_uploads": failed_uploads,
        }

    try:
        corpus_resource_name = "projects/d3v-agentzone/locations/us-east4/ragCorpora/5188146770730811392"

        transformation_config = rag.TransformationConfig(
            chunking_config=rag.ChunkingConfig(
                chunk_size=DEFAULT_CHUNK_SIZE,
                chunk_overlap=DEFAULT_CHUNK_OVERLAP,
            ),
        )
        
        total_imported_files = 0
        for path in validated_paths:
            try:
                print(f"Importing file: {path}")
                import_result = rag.import_files(
                    corpus_resource_name,
                    [path],
                    transformation_config=transformation_config,
                    max_embedding_requests_per_min=DEFAULT_EMBEDDING_REQUESTS_PER_MIN,
                )
                
                if import_result.imported_rag_files_count > 0:
                    total_imported_files += 1
                    print(f"✅ Successfully imported {path}")
                else:
                    failed_uploads.append({"path": path, "reason": "Import API reported 0 files imported."})

            except Exception as e:
                print(f"❌ Failed to import {path}: {e}")
                failed_uploads.append({"path": path, "reason": str(e)})


        if new_source_mappings:
            _update_source_mapping(new_source_mappings)

        if not tool_context.state.get("current_corpus"):
            tool_context.state["current_corpus"] = corpus_name
            
        success_message = f"Successfully added {total_imported_files} file(s) to corpus '{corpus_name}'."
        
        if skipped_preprocessing:
            success_message += f"\nWarning: The following files were uploaded without preprocessing: {', '.join(skipped_preprocessing)}"

        if failed_uploads:
            failed_reasons = [f"{f['path']} ({f['reason']})" for f in failed_uploads]
            success_message += f"\nError: The following files failed to upload, please try again: {', '.join(failed_reasons)}"

        return {
            "status": "success",
            "message": success_message,
            "corpus_name": corpus_name,
            "files_added": total_imported_files,
            "paths": validated_paths,
            "invalid_paths": invalid_paths,
            "conversions": conversions,
            "failed_uploads": failed_uploads,
            "skipped_preprocessing": skipped_preprocessing
        }

    except Exception as e:
        return {
            "status": "error",
            "message": f"Error adding data to corpus: {str(e)}",
            "corpus_name": corpus_name,
            "paths": validated_paths,
        }