LAB_REPORT_SCHEMA = '''{
    "file_url": "str",
    "file_name": "str",
    "report_header": {
        "title": "str",
        "company_name": "str",
        "company_website": "str",
        "astm_standards": ["str"]
    },
    "project_information": {
        "wsb_project_name": "str",
        "wsb_project_number": "str",
        "project_name": "str",
        "project_number": "str",
        "producer": "str"
    },
    "sample_identification": {
        "lab_number": "str",
        "mix_type": "str",
        "date_sampled": "str",
        "date_tested": "str",
        "mix_design": "str"
    },
    "sieve_analysis": {
        "title": "str",
        "results": [{
            "sieve_size_in": "str",
            "sieve_size_mm": "str",
            "jmf": "str",
            "spec": "str",
            "total_percent_passing": "str"
        }],
        "asphalt_content_percent": {
            "jmf": "str",
            "spec": "str",
            "total_percent_passing": "str"
        }
    },
    "material_properties": {
        "asphalt_concrete": {
            "moisture_and_volatiles": "str",
            "rice_maximum_specific_gravity": "str",
            "effective_specific_gravity": "str",
            "specific_gravity_of_ac": "str",
            "new_gsb": "str",
            "max_theoretical_specific_gravity_at_jmf": "str"
        }
    },
    "producer_information": {
        "ticket_number": "str",
        "tons": "str",
        "time": "str",
        "load_number": "str",
        "lot_number": "str"
    },
    "lab_molds": {
        "average_lab_molded_specific_gravity": "str",
        "lab_molded_densities_percent": {
            "value": "str",
            "spec": "str"
        },
        "air_voids_percent": {
            "value": "str",
            "spec": "str"
        },
        "voids_in_mineral_aggregate_percent": {
            "value": "str",
            "spec": "str"
        }
    },
    "graph_data": {
        "graph_points": [{
            "sieve_size_mm": "str",
            "total_percent_passing": "str"
        }]
    },
    "document_control": {
        "invoice_and_cc": "str",
        "cc_list": ["str"],
        "reviewed_by": "str",
        "remarks": "str"
    }
}'''
LAB_REPORT_PROMPT = """Extract lab report data into JSON. Follow the schema exactly. Skip missing fields. Return only JSON object that strictly follows the schema below."""
ODOT_DOCUMENT_SCHEMA = '''{
    "file_url": "str",
    "file_name": "str",
    "document_metadata": {
        "title": "str",
        "issuing_authority": "str",
        "document_type": "OKLAHOMA DEPARTMENT OF TRANSPORTATION SUPERPAVE HOT MIX ASPHALT SAMPLE SHEET"
    },
    "project_details": {
        "project_number": "str",
        "contractor": "str",
        "producer": "str",
        "lot_number": "int",
        "design_number": "str"
    },
    "sample_info": {
        "sample_id": "str",
        "date": "str",
        "time": "str",
        "mix_type": "str"
    },
    "key_results": {
        "corrected_asphalt_content_percent": "float",
        "average_rice_gravity_gmm": "float",
        "average_lab_molded_spec_grav_gmb": "float",
        "percent_air_voids": "float",
        "percent_vma": "float"
    }
}'''

ODOT_DOCUMENT_PROMPT = """You are an expert at parsing ODOT asphalt sample sheets. Extract data into JSON. Follow the schema exactly. Skip missing fields. Return only JSON."""