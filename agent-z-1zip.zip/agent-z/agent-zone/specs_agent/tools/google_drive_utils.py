import io
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaIoBaseDownload
from specs_agent.credentials import get_service_account_credentials

def get_files_from_folder(folder_id: str) -> list:
    """
    Lists all files in a given Google Drive folder, including those in Shared Drives.

    Args:
        folder_id: The ID of the Google Drive folder.

    Returns:
        A list of Google Drive file URLs within the folder.
    """
    try:
        creds = get_service_account_credentials()
        service = build('drive', 'v3', credentials=creds)
        files = []
        page_token = None
        while True:
            response = service.files().list(
                q=f"'{folder_id}' in parents",
                spaces='drive',
                fields='nextPageToken, files(id, name)',
                pageToken=page_token,
                supportsAllDrives=True,
                includeItemsFromAllDrives=True
            ).execute()
            for file in response.get('files', []):
                files.append(f"https://drive.google.com/file/d/{file.get('id')}/view")
            page_token = response.get('nextPageToken', None)
            if page_token is None:
                break
        return files
    except HttpError as error:
        print(f'An error occurred: {error}')
        return []

def download_file_from_drive(file_id: str) -> io.BytesIO:
    """
    Downloads a file from Google Drive.

    Args:
        file_id: The ID of the Google Drive file.

    Returns:
        The file content in a BytesIO object.
    """
    try:
        creds = get_service_account_credentials()
        service = build('drive', 'v3', credentials=creds)

        request = service.files().get_media(fileId=file_id)
        file_content = io.BytesIO()
        downloader = MediaIoBaseDownload(file_content, request)
        done = False
        while done is False:
            status, done = downloader.next_chunk()
            if status:
                print(F'Download {int(status.progress() * 100)}.')

        file_content.seek(0)
        return file_content
    except HttpError as error:
        print(f'An error occurred while downloading file {file_id}: {error}')
        return None

def get_file_name_from_drive(file_id: str) -> str:
    """
    Gets the file name of a file in Google Drive.

    Args:
        file_id: The ID of the Google Drive file.

    Returns:
        The file name.
    """
    try:
        creds = get_service_account_credentials()
        service = build('drive', 'v3', credentials=creds)

        file_metadata = service.files().get(fileId=file_id, fields='name').execute()
        return file_metadata.get('name')
    except HttpError as error:
        print(f'An error occurred while getting file metadata for {file_id}: {error}')
        return None