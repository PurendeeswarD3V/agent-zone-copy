# Build and run the Docker container

Write-Host "Building Docker image..." -ForegroundColor Green
docker build -t rag-agent .

Write-Host "Running Docker container..." -ForegroundColor Green
docker run -p 8000:8000 --name rag-agent-container rag-agent
