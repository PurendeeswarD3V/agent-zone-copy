from google.cloud import storage
import config

class GCSUploadError(Exception):
    """Custom exception for GCS upload failures."""
    pass

def upload_to_gcs(file_obj, destination_blob_name: str) -> str:
    """
    Upload a file-like object (e.g., FastAPI UploadFile) to GCS and return the public URL.
    """
    try:
        client = storage.Client()
        bucket = client.bucket(config.GCS_BUCKET_NAME_logos)
        blob = bucket.blob(destination_blob_name)
        blob.upload_from_file(file_obj.file, content_type=file_obj.content_type)

        # Make the file public (optional)
        # blob.make_public()
        return f"https://storage.googleapis.com/{bucket.name}/{destination_blob_name}"
    except Exception as e:
        raise GCSUploadError(f"GCS upload failed: {e}")