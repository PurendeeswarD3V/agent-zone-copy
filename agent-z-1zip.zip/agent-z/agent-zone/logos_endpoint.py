from http.client import HTTPException
from typing import List, Optional, Union
from pydantic import BaseModel
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, status
from gcs_utils import upload_to_gcs, GCSUploadError
from logo_databade import insert_agent_record, fetch_all_agents, delete_agent_record, update_agent_record, fetch_agent_record
import uuid
import config
router = APIRouter(prefix="/logos", tags=["Logos Table"])

class LogoCreateRequest(BaseModel):
    org_id: int
    agent_name: str
    version_id: str
    logo: Optional[str] = None


class LogoUpdateRequest(BaseModel):
    agent_name: Optional[str] = None
    logo: Optional[str] = None
    version_id: Optional[str] = None



@router.get("/", response_model=List[dict])
async def list_logos():
    """
    Fetch all records from the logos table.
    """
    return fetch_all_agents()

@router.get("/{org_id}", response_model=dict)
async def get_logo(org_id: str):
    """
    Fetch a specific record by org_id from the logos table.
    """
    agent = fetch_agent_record(org_id)
    if agent:
        return {
            "logo": agent["logo"],
            "agent_name": agent["agent_name"],
                "version_id": agent["version_id"],
            }
    raise HTTPException(status_code=404, detail="Record not found")

@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_logo(
        org_id: str = Form(...),
        agent_name: str = Form(...),
        version_id: str = Form(...),
        logo_file: UploadFile = File(...)
    ):
    try:
        # Generate unique name for GCS
        ext = logo_file.filename.split(".")[-1]
        gcs_filename = f"logos/{org_id}/{uuid.uuid4()}.{ext}"

        # Upload to GCS
        public_url = upload_to_gcs(logo_file, gcs_filename)

        # Insert DB record
        insert_agent_record(
            org_id=org_id,
            agent_name=agent_name,
            version_id=version_id,
            logo=public_url,
        )

        return {
            "status": "success",
            "message": "Logo record created successfully",
            "data": {
                "org_id": org_id,
                "agent_name": agent_name,
                "version_id": version_id,
                "logo_url": public_url,
            },
        }

    except GCSUploadError as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{org_id}")
async def update_logo(
    org_id: str,
    agent_name: Optional[str] = Form(None),
    version_id: Optional[str] = Form(None),
    logo_file: Optional[Union[UploadFile, str]] = File(None)
):
    """
    Update logo, version_id or agent_name for a specific record.
    Any of these fields may be omitted.
    """
    try:
        public_url = None

        # ✅ Only upload if a file was provided
        if logo_file is not None and hasattr(logo_file, "filename"):
            ext = logo_file.filename.split(".")[-1]
            gcs_filename = f"logos/{org_id}/{uuid.uuid4()}.{ext}"
            public_url = upload_to_gcs(logo_file, gcs_filename)
        # ✅ Only call update if at least one field was provided
        if agent_name or version_id or public_url:
            update_agent_record(org_id, agent_name, public_url, version_id)
        else:
            return {
                "status": "no_update",
                "message": "No fields provided to update"
            }

        return {"status": "success", "message": "Logo record updated successfully"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/{org_id}")
async def delete_logo(org_id: str):
    """
    Delete a record from the logos table.
    """
    try:
        delete_agent_record(org_id)
        return {"status": "success", "message": "Logo record deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))