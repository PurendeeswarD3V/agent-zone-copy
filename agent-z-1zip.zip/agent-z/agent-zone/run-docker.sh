#!/bin/bash
# Build and run the Docker container

echo "Building Docker image..."
docker build -t rag-agent .

echo "Running Docker container..."
docker run -p 8000:8000 --name rag-agent-container rag-agent
