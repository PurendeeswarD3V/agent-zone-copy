from fastapi import APIRouter, Query, HTTPException, status
from pydantic import BaseModel
from typing import List, Optional
from .tools import list_corpora, get_corpus_info, delete_corpus, create_corpus, add_data
from google.adk.tools.tool_context import ToolContext
from google.adk.agents.invocation_context import InvocationContext

router = APIRouter(prefix="/corpus", tags=["Corpus Management"])

def get_tool_context(user_id: str = "external-user") -> ToolContext:
    """
    Always return a ToolContext with a dummy InvocationContext,
    so endpoints outside ADK can still call ADK tools.
    """
    invocation_context = InvocationContext(user_id=user_id)
    return ToolContext(invocation_context=invocation_context)

class CreateCorpusRequest(BaseModel):
    corpus_name: str


@router.get("/list")
async def get_corpora():
    """
    List all available Vertex AI RAG corpora.
    """
    result = list_corpora()
    if result.get("status") == "error":
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=result["message"],
        )
    return {
        "status": "success",
        "message": "Corpora retrieved successfully",
        "data": result.get("corpora", []),
    }


@router.get("/{corpus_name}")
async def get_corpus_details(corpus_name: str):
    """
    Get detailed information about a specific RAG corpus, including its files.
    """
    tool_context = get_tool_context()
    result = get_corpus_info(corpus_name=corpus_name, tool_context=tool_context)

    if result.get("status") == "error":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=result["message"],
        )
    return {
        "status": "success",
        "message": result.get("message", "Corpus details retrieved"),
        "data": result,
    }


@router.delete("/{corpus_name}")
async def remove_corpus(corpus_name: str):
    """
    Delete a Vertex AI RAG corpus.
    """
    tool_context = get_tool_context()
    result = delete_corpus(corpus_name=corpus_name, tool_context=tool_context)

    if result.get("status") == "error":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=result["message"],
        )
    return {
        "status": "success",
        "message": result["message"],
    }



@router.post("/create")
async def add_corpus(request: CreateCorpusRequest):
    """
    Create a new Vertex AI RAG corpus.
    """
    tool_context = get_tool_context()
    result = create_corpus(corpus_name=request.corpus_name, tool_context=tool_context)

    if result.get("status") == "error":
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=result["message"],
        )

    return {
        "status": "success",
        "message": result["message"],
        "data": {
            "corpus_name": result.get("corpus_name"),
            "display_name": result.get("display_name"),
        },
    }

class AddDataRequest(BaseModel):
    corpus_name: str
    paths: List[str]

@router.post("/add-data")
async def add_data_to_corpus(request: AddDataRequest):
    """
    Add new data sources (Google Drive links or GCS paths) to a Vertex AI RAG corpus.
    """
    tool_context = get_tool_context()
    result = add_data(
        corpus_name=request.corpus_name,
        paths=request.paths,
        tool_context=tool_context,
    )

    if result.get("status") == "error":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=result["message"],
        )

    return {
        "status": "success",
        "message": result["message"],
        "data": result,
    }

