import mysql.connector
from mysql.connector import Error as MySQLError
from typing import Optional
import config

# Capture config values once so they're available even if config behaves differently in staging
DB_HOST = config.MYSQL_HOST
DB_USER = config.MYSQL_USER
DB_PASSWORD = config.MYSQL_PASSWORD
DB_NAME = config.MYSQL_DATABASE

DB_CONFIG = {
    "host": DB_HOST,
    "user": DB_USER,
    "password": DB_PASSWORD,
    "database": DB_NAME,
}


def get_db_connection():
    """Create and return a new MySQL DB connection."""
    return mysql.connector.connect(**DB_CONFIG)


def insert_agent_record(org_id: str, agent_name: str, version_id: str, logo: Optional[str] = None):
    """Insert a new record into the `logos` table."""
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO logos (org_id, logo, agent_name, version_id)
            VALUES (%s, %s, %s, %s)
            """,
            (org_id, logo, agent_name, version_id),
        )
        conn.commit()
    except MySQLError as e:
        print("DB Insert Error:", e)
        raise
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None and conn.is_connected():
            conn.close()


def fetch_all_agents():
    """Fetch all records from the `logos` table."""
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM logos")
        return cursor.fetchall()
    except MySQLError as e:
        print("DB Fetch Error:", e)
        return []
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None and conn.is_connected():
            conn.close()


def fetch_agent_record(org_id: str):
    """Fetch a specific record by org_id from the logos table."""
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM logos WHERE org_id = %s", (org_id,))
        return cursor.fetchone()
    except MySQLError as e:
        print("DB Fetch Error:", e)
        return None
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None and conn.is_connected():
            conn.close()


def delete_agent_record(org_id: str):
    """Delete a record from the logos table by org_id."""
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM logos WHERE org_id = %s", (org_id,))
        conn.commit()
    except MySQLError as e:
        print("DB Delete Error:", e)
        raise
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None and conn.is_connected():
            conn.close()


def update_agent_record(org_id: str,
                        agent_name: Optional[str] = None,
                        logo: Optional[str] = None,
                        version_id: Optional[str] = None):
    """Update one or more fields of a record in the logos table."""
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        fields = []
        params = []

        if logo is not None:
            fields.append("logo=%s")
            params.append(logo)
        if version_id is not None:
            fields.append("version_id=%s")
            params.append(version_id)
        if agent_name is not None:
            fields.append("agent_name=%s")
            params.append(agent_name)

        if not fields:
            return  # nothing to update

        query = f"UPDATE logos SET {', '.join(fields)} WHERE org_id=%s"
        params.append(org_id)

        cursor.execute(query, tuple(params))
        conn.commit()
    except MySQLError as e:
        print("DB Update Error:", e)
        raise
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None and conn.is_connected():
            conn.close()
