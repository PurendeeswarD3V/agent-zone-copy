"""
Configuration settings for the RAG Agent.

These settings are used by the various RAG tools.
Vertex AI initialization is performed in the package's __init__.py
"""

import os

from dotenv import load_dotenv

# Load environment variables (this is redundant if __init__.py is imported first,
# but included for safety when importing config directly)
load_dotenv()

# Vertex AI settings
PROJECT_ID = os.environ.get("GOOGLE_CLOUD_PROJECT")
LOCATION = os.environ.get("GOOGLE_CLOUD_LOCATION")
GCS_BUCKET_NAME = os.environ.get("GCS_BUCKET_NAME")
GCS_BUCKET_NAME_logos = os.environ.get("GCS_BUCKET_NAME_LOGOS")

# RAG settings
DEFAULT_CHUNK_SIZE = 512
DEFAULT_CHUNK_OVERLAP = 100
DEFAULT_TOP_K = 50
DEFAULT_DISTANCE_THRESHOLD = 0.5
DEFAULT_EMBEDDING_MODEL = "publishers/google/models/text-embedding-005"
DEFAULT_EMBEDDING_REQUESTS_PER_MIN = 1000
# DEFAULT_BATCH_SIZE = 20

# JWT settings
JWT_SECRET = os.environ.get("JWT_SECRET", "change-me-in-production")
JWT_ALGORITHM = os.environ.get("JWT_ALGORITHM", "HS256")

# MySQL settings
MYSQL_HOST = os.environ.get("MYSQL_HOST", "localhost")
MYSQL_PORT = int(os.environ.get("MYSQL_PORT", "3306"))
MYSQL_USER = os.environ.get("MYSQL_USER", "root")
MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "1234")
MYSQL_DATABASE = os.environ.get("MYSQL_DATABASE", "agent_zone")

# Query configuration (column and table names can vary by installation)
USER_TABLE_NAME = os.environ.get("USER_TABLE_NAME", "users")
USER_ID_COLUMN = os.environ.get("USER_ID_COLUMN", "user_id")
TENANT_ID_COLUMN = os.environ.get("TENANT_ID_COLUMN", "tenant_id")
ORG_ID_COLUMN = os.environ.get("ORG_ID_COLUMN", "org_id")
USERNAME_LOOKUP_COLUMN = os.environ.get("USERNAME_LOOKUP_COLUMN", "username")

# Logos table configuration
LOGOS_TABLE_NAME = os.environ.get("LOGOS_TABLE_NAME", "logos")
LOGOS_ORG_ID_COLUMN = os.environ.get("LOGOS_ORG_ID_COLUMN", "org_id")
LOGOS_LOGO_COLUMN = os.environ.get("LOGOS_LOGO_COLUMN", "logo")
LOGOS_AGENT_NAME_COLUMN = os.environ.get("LOGOS_AGENT_NAME_COLUMN", "agent_name")
LOGOS_VERSION_ID_COLUMN = os.environ.get("LOGOS_VERSION_ID_COLUMN", "version_id")