# Vertex AI RAG Agent

This project provides a Retrieval-Augmented Generation (RAG) agent that interacts with Google Cloud Vertex AI and Google Drive. It can manage and query document corpora, automatically classifying and preprocessing documents before ingestion.

---

## Prerequisites

* A Google Cloud account with billing enabled
* A Google Cloud project with the Vertex AI API enabled
* Appropriate access to create and manage Vertex AI resources
* **Python 3.10+**
* **Poppler**: A PDF rendering library required for document processing.

---

## Setting Up Google Cloud Authentication

Before running the agent, you need to set up authentication with Google Cloud:

1. **Install Google Cloud CLI**:
   - Visit [Google Cloud SDK](https://cloud.google.com/sdk/docs/install) for installation instructions for your OS

2. **Initialize the Google Cloud CLI**:
   ```bash
   gcloud init
   ```
   This will guide you through logging in and selecting your project.

3. **Set up Application Default Credentials**:
   ```bash
   gcloud auth application-default login
   ```
   This will open a browser window for authentication and store credentials in:
   `~/.config/gcloud/application_default_credentials.json`

4. **Verify Authentication**:
   ```bash
   gcloud auth list
   gcloud config list
   ```

5. **Enable Required APIs** (if not already enabled):
   ```bash
   gcloud services enable aiplatform.googleapis.com
   ```

---

## Installation

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/d3vtech/agent-zone.git
    cd agent-zone
    ```

2.  **Create and activate a virtual environment:**
    ```bash
    python -m venv venv
    # On Windows
    .\venv\Scripts\activate
    # On macOS/Linux
    source venv/bin/activate
    ```

3.  **Install Poppler:**

    * **Windows**:
        1.  Download the [latest Poppler binary for Windows](https://github.com/oschwartz10612/poppler-windows/releases/).
        2.  Extract the downloaded archive to a location on your system (e.g., `C:\poppler`).
        3.  Add the `\bin` directory from the extracted folder to your system's PATH environment variable.

    * **macOS (using Homebrew)**:
        ```bash
        brew install poppler
        ```

    * **Linux (Debian/Ubuntu)**:
        ```bash
        sudo apt-get update && sudo apt-get install -y poppler-utils
        ```

4.  **Install Python dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

---

## Configuration

1.  **Set up your environment:**
    Create a `.env` file in the `rag_agent` directory by copying the `.env.example`.

2.  **Fill in the `.env` file with your project details:**
    * `GOOGLE_CLOUD_PROJECT`: Your Google Cloud Project ID.
    * `GOOGLE_CLOUD_LOCATION`: The region for your project (e.g., `us-central1`).
    * `GCS_BUCKET_NAME`: The name of the Google Cloud Storage bucket for processed files.
    * `SA_KEY_PATH`: The absolute path to your Google Cloud Service Account JSON key file.
    * `GDRIVE_CLIENT_ID` & `GDRIVE_CLIENT_SECRET`: Your OAuth 2.0 Client ID and Secret for Google Drive access.

3.  **Google Cloud Authentication:**
    * **Vertex AI:** Ensure your service account has the "Vertex AI User" role.
    * **Google Drive:** The first time you run the agent, you will be prompted to authenticate via a browser popup to grant Google Drive access. A `token.json` file will be created to store your credentials.

---

## Running the Agent

Launch the agent's web interface using the ADK CLI:

```bash
adk web
```

Access the web UI at `http://localhost:8000`.

---

## Agent Actions

You can interact with the agent through the web UI to perform the following actions:

* **`create_corpus [corpus_name]`**: Create a new document corpus.
* **`list_corpora`**: List all available corpora.
* **`add_data`**: Add documents from Google Drive to a corpus. The agent will:
    * Classify files as `LAB_REPORT`, `ODOT_DOCUMENT`, or `UNKNOWN`.
    * Preprocess `LAB_REPORT` and `ODOT_DOCUMENT` files with Gemini.
    * Directly ingest `UNKNOWN` files.
* **`rag_query [query]`**: Ask a question to get answers from a corpus.
* **`get_corpus_info [corpus_name]`**: Get details about a specific corpus.
* **`delete_document [document_id]`**: Delete a specific document from a corpus.
* **`delete_corpus [corpus_name]`**: Delete an entire corpus.

---
## Additional Resources

- [Vertex AI RAG Documentation](https://cloud.google.com/vertex-ai/generative-ai/docs/rag-overview)
- [Google Agent Development Kit (ADK) Documentation](https://github.com/google/agents-framework)
- [Google Cloud Authentication Guide](https://cloud.google.com/docs/authentication)