import os
import warnings
import logging
import json
import vertexai
from dotenv import load_dotenv
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from google.adk.cli.fast_api import get_fast_api_app
from config import PROJECT_ID, LOCATION
# from endpoints import router as corpus_router
from logos_endpoint import router as logos_router
# from client_controller_service.auth_endpoints import router as auth_router

# Load environment variables
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
load_dotenv(dotenv_path=dotenv_path)


vertexai.init(project=PROJECT_ID, location=LOCATION)

warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=UserWarning)

AGENT_DIR = os.path.dirname(os.path.abspath(__file__))
logger = logging.getLogger(__name__)


# Allowed origins for CORS
ALLOWED_ORIGINS = [
    "http://localhost:3000",  # React dev server
    "http://localhost:3001",  # React dev server
    "http://localhost:8080",  # React dev server
    "http://localhost:8000",  # FastAPI dev server
    "https://agentzone-backend-staging-1001673151400.us-east4.run.app",  # Staging backend
    "https://agentzone-frontend-staging-1001673151400.us-central1.run.app"  # Staging frontend
]

# Create the FastAPI app
app: FastAPI = get_fast_api_app(
    agents_dir=AGENT_DIR,
    web=True,
)

# Add CORS middleware with additional configurations
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
    max_age=600  # Cache preflight requests for 10 minutes
)

# Add OPTIONS handler for CORS preflight
@app.options("/{full_path:path}")
async def options_handler(full_path: str):
    return {"method": "OPTIONS"}

# Include custom routers
# app.include_router(corpus_router)
# app.include_router(auth_router)
app.include_router(logos_router)


if __name__ == "__main__":
    print("Starting FastAPI server...")
    port = int(os.environ.get("PORT", 8080))
    logger.info(
        f"Starting FastAPI server | {json.dumps({'host': '0.0.0.0', 'port': port, 'reload': False})}"
    )
    uvicorn.run(app, host="0.0.0.0", port=port, reload=False)